# Skyhostr Mobile Hosting Server

Mobile দিয়ে নিজের Hosting Server চালানোর সম্পূর্ণ গাইড।

## Features

✅ PHP Web Server  
✅ Cloudflare Tunnel  
✅ Custom Domain Support  
✅ WiFi + Mobile Data Support  
✅ TinyFileManager File Manager  
✅ One Command Start  
✅ One Command Stop  
✅ Backup & Restore Support  


# Folder Structure

mobile-hosting-server

├── README.md
├── install.sh
├── sky
├── stop
├── start.sh
├── config.yml
└── public_html

    ├── index.php
    └── tinyfilemanager.php


# New Phone Setup (A to Z)


## 1. Install Termux

Install Termux from:

https://f-droid.org/packages/com.termux/


Open Termux:


Update packages:

```
pkg update -y
pkg upgrade -y
```


Install required packages:

```
pkg install php git nano cloudflared zip unzip -y
```


# 2. Clone GitHub Repository


```
cd ~
git clone https://github.com/tzalmamun/mobile-hosting-server.git
```


Enter folder:

```
cd mobile-hosting-server
```


# 3. Give Permission

```
chmod +x sky
chmod +x stop
chmod +x install.sh
```


# 4. Install Server


Run:

```
./install.sh
```


# 5. Cloudflare Login


```
cloudflared tunnel login
```


Browser open হলে Cloudflare account select করুন।


# 6. Create Tunnel


```
cloudflared tunnel create skyhostr
```


Tunnel ID copy করে রাখুন।


# 7. Config Setup


Open:

```
nano ~/.cloudflared/config.yml
```


Example:

```
tunnel: YOUR-TUNNEL-ID

credentials-file: /data/data/com.termux/files/home/.cloudflared/YOUR-TUNNEL-ID.json


ingress:

- hostname: tzalmamun.online
  service: http://localhost:8080

- hostname: www.tzalmamun.online
  service: http://localhost:8080

- service: http_status:404
```


Save:

CTRL + O

Enter

CTRL + X


# 8. DNS Connect


Run:


```
cloudflared tunnel route dns skyhostr tzalmamun.online
```


and


```
cloudflared tunnel route dns skyhostr www.tzalmamun.online
```


# Start Server


শুধু লিখুন:


```
sky
```


Server চালু হবে।


Website:

```
https://tzalmamun.online

https://www.tzalmamun.online
```



# Stop Server


Server বন্ধ:


```
stop
```


অথবা:


```
pkill php
pkill cloudflared
```



# File Manager


File Manager:

```
https://tzalmamun.online/tinyfilemanager.php
```



# TinyFileManager Password Change


File open করুন:


```
nano public_html/tinyfilemanager.php
```


খুঁজুন:


```
'admin'
```


এবং password পরিবর্তন করুন।


Example:


```
'admin123'
```


Save করুন।



# Backup


পুরো server backup:


```
cd ~

zip -r skyhostr-backup.zip mobile-hosting-server .cloudflared
```


Backup file পাবেন:


```
/data/data/com.termux/files/home/
```



এটি Google Drive এ রাখুন।



# Restore New Phone


Backup file Internal Storage এ রাখুন।


Move করুন:


```
termux-setup-storage
```


তারপর:


```
cp /sdcard/skyhostr-backup.zip ~/
```


Extract:


```
unzip skyhostr-backup.zip
```



Cloudflare restore:


```
cp -r .cloudflared ~/
```


Permission:


```
chmod +x sky
chmod +x stop
```


Start:


```
sky
```



# Troubleshooting


## DNS Problem


Run:


```
pkill cloudflared
sky
```


## Tunnel Problem


Check:


```
cloudflared tunnel list
```


## PHP Problem


Restart:


```
pkill php
sky
```



# Important

Phone বন্ধ হলে server বন্ধ হবে।

আবার চালু করতে:

```
sky
```


এই এক কমান্ডেই সব চালু হবে।


# Developer

Skyhostr Mobile Hosting Server

GitHub:

https://github.com/tzalmamun/mobile-hosting-server