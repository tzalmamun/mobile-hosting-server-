alias server="~/startserver"
alias server="~/startserver"
alias sky="~/sky"
alias sky="~/sky"
export PATH=$PATH:$HOME
