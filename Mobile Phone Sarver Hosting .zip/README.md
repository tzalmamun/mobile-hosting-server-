# Skyhostr Mobile Hosting Server Restore Guide

## Backup File Name

skyhostr-backup.tar.gz


# নতুন ফোনে Setup করার নিয়ম (A to Z)

## Step 1: Termux Install

নতুন ফোনে Termux ইনস্টল করুন।

তারপর লিখুন:

pkg update && pkg upgrade


## Step 2: প্রয়োজনীয় Package Install

কমান্ড:

pkg install php cloudflared tar nano wget


## Step 3: Backup File Internal Storage এ রাখুন

ফাইল রাখবেন:

Internal Storage/
      |
      └── skyhostr-backup.tar.gz


## Step 4: Storage Permission দিন

Termux এ লিখুন:

termux-setup-storage


Allow চাপুন।


## Step 5: Backup Home Folder এ কপি করুন

কমান্ড:

cp /sdcard/skyhostr-backup.tar.gz ~/


## Step 6: Restore করুন

কমান্ড:

cd ~

tar -xzvf skyhostr-backup.tar.gz


## Step 7: Permission দিন

কমান্ড:

chmod +x ~/sky

chmod +x ~/stop


## Step 8: Server Start

শুধু লিখুন:

sky


এতে চালু হবে:

✓ PHP Server
✓ Cloudflare Tunnel
✓ Domain Connection
✓ File Manager


## Step 9: Server Stop

বন্ধ করতে:

stop


# Website Open

Domain:

https://tzalmamun.online

https://www.tzalmamun.online


File Manager:

https://tzalmamun.online/tinyfilemanager.php


# Important Files

Cloudflare Config:

~/.cloudflared/


Website Files:

~/public_html/


Start Command:

~/sky


Stop Command:

~/stop



# যদি নতুন ফোনে সমস্যা হয়

Tunnel Check:

cloudflared tunnel list


PHP Check:

php -v


Restart:

stop

তারপর

sky



# Backup Update করার নিয়ম

নতুন পরিবর্তনের পর আবার Backup নিতে:

cd ~

tar -czvf skyhostr-backup.tar.gz .cloudflared public_html sky stop .bashrc


তারপর:

cp skyhostr-backup.tar.gz /sdcard/


শেষ।