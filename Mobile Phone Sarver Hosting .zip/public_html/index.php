<!DOCTYPE html>
<html>
<head>
<title>Al Mamun Sheikh</title>
<style>
body{
    font-family: Arial;
    background:#f2f2f2;
    text-align:center;
    padding:50px;
}
.card{
    background:white;
    padding:30px;
    border-radius:15px;
    max-width:400px;
    margin:auto;
    box-shadow:0 0 10px #ccc;
}
h1{
    color:#2563eb;
}
a{
    text-decoration:none;
    color:#16a34a;
}
</style>
</head>

<body>

<div class="card">

<h1>Al Mamun Sheikh</h1>

<p>Welcome to my personal bio page</p>

<p>📞 09638471147</p>

<p>✉️ info@skyhostr.com</p>

<p>
<a href="mailto:info@skyhostr.com">Send Email</a>
</p>

</div>

</body>
</html>

