<?php
// Hosting Package Data
$package_name = "BDIX 1GB Hosting";
$price = "৳49";
$duration = "প্রতি মাস";

$features = [
    "1 Domain Host করা যাবে",
    "1GB SSD Storage",
    "Unlimited Bandwidth",
    "2 Email Account",
    "2 MySQL Database",
    "1 Sub Domain",
    "Free SSL Certificate",
    "cPanel Control Panel"
];
?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $package_name; ?></title>

<style>
body{
    margin:0;
    font-family: Arial, sans-serif;
    background:#f4f7fb;
}

.container{
    max-width:400px;
    margin:50px auto;
    padding:20px;
}

.card{
    background:white;
    border-radius:15px;
    padding:30px;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
    text-align:center;
}

.card h1{
    color:#2563eb;
    font-size:25px;
}

.price{
    font-size:35px;
    font-weight:bold;
    color:#16a34a;
}

.price span{
    font-size:15px;
    color:#555;
}

ul{
    list-style:none;
    padding:0;
    text-align:left;
}

ul li{
    padding:10px;
    border-bottom:1px solid #eee;
}

ul li:before{
    content:"✓ ";
    color:#16a34a;
    font-weight:bold;
}

.button{
    display:block;
    margin-top:25px;
    background:#2563eb;
    color:white;
    padding:12px;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
}

.button:hover{
    background:#1d4ed8;
}

.badge{
    background:#16a34a;
    color:white;
    padding:5px 15px;
    border-radius:20px;
    display:inline-block;
}
</style>

</head>

<body>

<div class="container">

<div class="card">

<div class="badge">Popular Plan</div>

<h1><?php echo $package_name; ?></h1>

<div class="price">
<?php echo $price; ?>
<span>/ <?php echo $duration; ?></span>
</div>

<ul>
<?php
foreach($features as $feature){
    echo "<li>$feature</li>";
}
?>
</ul>

<a href="#" class="button">
Order Now
</a>

</div>

</div>

</body>
</html>