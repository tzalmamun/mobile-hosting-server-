আপনার জন্য একটি README.md তৈরি করে দিচ্ছি, যেখানে A to Z থাকবে — নতুন ফোনে Google Drive থেকে backup এনে আবার setup করার নিয়ম, সব কমান্ড, Sky command, Cloudflare Tunnel, PHP Server, File Manager ইত্যাদি।

এটা আপনি আপনার mobile-hosting-server/README.md এ রাখবেন।

# 🚀 Skyhostr Mobile Hosting Server

একটি Android ফোনকে PHP Web Server + Cloudflare Tunnel দিয়ে নিজের Domain এ চালানোর সম্পূর্ণ Setup Guide.

## Features

✅ PHP Server  
✅ Cloudflare Tunnel  
✅ Custom Domain Support  
✅ HTTPS Support  
✅ File Manager  
✅ One Command Start (sky)  
✅ Stop Command  
✅ Backup & Restore Support  


# 📁 Project Structure

mobile-hosting-server

mobile-hosting-server │ ├── README.md ├── install.sh ├── sky ├── stop ├── config.yml.example │ └── public_html ├── index.php └── tinyfilemanager.php

# 1. Termux Install

প্রথমে Termux Install করুন।

তারপর:

```bash
pkg update -y
pkg upgrade -y

pkg install php git nano curl wget cloudflared -y

2. GitHub থেকে Download

cd ~

git clone https://github.com/tzalmamun/mobile-hosting-server

cd mobile-hosting-server

3. Permission দিন

chmod +x sky
chmod +x stop
chmod +x install.sh

4. Install চালু করুন

./install.sh

5. Cloudflare Login

cloudflared tunnel login

Browser থেকে Cloudflare Account Login করুন।

6. Tunnel Create

cloudflared tunnel create skyhostr

Tunnel ID কপি করে রাখবেন।

7. Config Setup

ফাইল খুলুন:

nano ~/.cloudflared/config.yml

লিখুন:

tunnel: YOUR-TUNNEL-ID

credentials-file: /data/data/com.termux/files/home/.cloudflared/YOUR-TUNNEL-ID.json


ingress:

 - hostname: tzalmamun.online
   service: http://localhost:8080

 - hostname: www.tzalmamun.online
   service: http://localhost:8080

 - service: http_status:404

Save:

CTRL + O
Enter
CTRL + X

8. Domain Connect

cloudflared tunnel route dns skyhostr tzalmamun.online

cloudflared tunnel route dns skyhostr www.tzalmamun.online

9. Server Start

শুধু লিখুন:

sky

তাহলে চালু হবে:

✅ PHP Server
✅ Cloudflare Tunnel
✅ Domain Connection

10. Server Stop

লিখুন:

stop

সব বন্ধ হবে।

11. File Manager

Browser এ যান:

https://tzalmamun.online/tinyfilemanager.php

অথবা

https://www.tzalmamun.online/tinyfilemanager.php

12. Backup নেওয়া

Backup তৈরি:

cd ~

tar -czvf skyhostr-backup.tar.gz mobile-hosting-server ~/.cloudflared

Backup File থাকবে:

/data/data/com.termux/files/home/

নাম:

skyhostr-backup.tar.gz

এটি Google Drive এ Upload করুন।

13. নতুন ফোনে Restore

নতুন ফোনে:

Termux Install করুন।

Package Install:

pkg update

pkg install tar cloudflared php nano git -y

Google Drive থেকে:

skyhostr-backup.tar.gz

Internal Storage এ রাখুন।

তারপর:

termux-setup-storage

Copy করুন:

cp /sdcard/skyhostr-backup.tar.gz ~/

Restore:

cd ~

tar -xzvf skyhostr-backup.tar.gz

Permission:

chmod +x ~/mobile-hosting-server/sky

chmod +x ~/mobile-hosting-server/stop

14. Run

sky

সব আগের মতো চালু হবে।

15. যদি Domain কাজ না করে

Check:

cloudflared tunnel list

Tunnel চালু কিনা দেখুন।

DNS Check:

cloudflared tunnel info skyhostr

Important

Phone Internet Change হলে:

WiFi থেকে SIM

অথবা

SIM থেকে WiFi

Cloudflare Tunnel নিজে নিজে Reconnect করবে।

Commands List

Start:

sky

Stop:

stop

Check Tunnel:

cloudflared tunnel list

PHP Server:

php -S 0.0.0.0:8080

Developer

Skyhostr Mobile Hosting Server

GitHub: https://github.com/tzalmamun/mobile-hosting-server

এটা রাখলে ভবিষ্যতে নতুন ফোনে শুধু **backup restore + `sky` command** দিলেই আগের setup ফিরে পাবেন।